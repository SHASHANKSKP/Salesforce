({
	callaccount : function(component, event, helper) {
		var req=component.get("c.showAccounts");
        req.setParams({"recCount":component.get("v.recordCount")})
        $A.enqueueAction(req);
        
        req.setCallback(this,function(res){
            if(res.getState()=="SUCCESS"){
                var resValue=res.getReturnValue();
                component.set("v.acclist",resValue);
            }
        })
	}
})