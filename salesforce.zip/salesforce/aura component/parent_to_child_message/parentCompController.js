({
	changeMsg : function(component, event, helper) {
		component.set("v.parentMsg", "Okay done...");
	}
})