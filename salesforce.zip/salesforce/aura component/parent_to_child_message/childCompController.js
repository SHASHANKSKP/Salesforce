({
	changeMsg : function(component, event, helper) {
        component.set("v.msg","Okay,see you later...");
		
	}
})