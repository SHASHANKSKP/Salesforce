({
	handleClick : function(component, event, helper) {
        var msg=component.get('v.msg');
        var btnLabel=event.getSource().get('v.label');
        if(btnLabel=='Save'){
            event.getSource().set("v.label","Commit");
            event.getSource().set('v.variant','base');
        }else
        {
            event.getSource().set("v.label","Save");
            event.getSource().set('v.variant','brand');
        }
		
        component.set('v.msg','Changed Message');
	}
})