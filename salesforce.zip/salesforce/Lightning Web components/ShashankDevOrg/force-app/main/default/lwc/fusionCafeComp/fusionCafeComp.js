import { LightningElement } from 'lwc';

export default class FusionCafeComp extends LightningElement {

    items = [
        {
            itemName: 'Samosa',
            itemType: 'Food',
            quantity: 10,
            price:12,
        },
        {
            itemName:'Sprite',
            itemType: 'Drinks',
            quantity:2,
            price:40,
        },
        {
            itemName:'Nestle',
            itemType: 'Chocolate',
            quantity: 4,
            price:10,
        },
    ];
}