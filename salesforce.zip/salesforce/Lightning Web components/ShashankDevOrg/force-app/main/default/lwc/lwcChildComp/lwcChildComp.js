import { LightningElement } from 'lwc';

export default class LwcChildComp extends LightningElement {}