import { LightningElement,track,wire } from 'lwc';
import getEmployeeList from '@salesforce/apex/Employee2Controller.getEmployeeList';
import { deleteRecord } from 'lightning/uiRecordApi';
import { NavigationMixin } from 'lightning/navigation';
import { refreshApex } from '@salesforce/apex';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import NAME_FIELD from '@salesforce/schema/Employee2__c.Name';
import Email from '@salesforce/schema/Employee2__c.Email__c';
import Organisation from '@salesforce/schema/Employee2__c.Organisation__c';
const COLS = [
    { label: 'Name', fieldName: 'Name', editable: true },
    { label: 'Email', fieldName: 'Email__c', type: 'email' },
    { label: 'Organisation', fieldName: 'Organisation__c' },
    
];
export default class Employee2 extends NavigationMixin(LightningElement) {
    @track error;
    @track columns = COLS;
    @track draftValues = [];
    @track employees;


    @wire(getEmployeeList)
        wiredEmployee({error,data})
        {
            console.log('groot');
            if(data){
                this.employees=data;
                this.error=undefined;
            }
            if(error){
                this.employees=undefined;
                this.error=error;
            } 
        }
        
        editRecord(){
            this.record=this.template.querySelector('lightning-datatable').getSelectedRows()[0].Id;
            console.log(this.record);
            this[NavigationMixin.Navigate]({
                type: 'standard__recordPage',
                attributes: {
                    recordId: this.record,
                    objectApiName: "Employee2__c",
                    actionName: "edit"  
                },
            });
        }
        createNew(){
            this[NavigationMixin.Navigate]({
                type: 'standard__objectPage',
                attributes: {
                    "objectApiName": "Employee2__c",
                    "actionName": "new"
                },
            });
        }
        
        deleteRecord(){
            console.log('start deleting ');
            var empId=(this.template.querySelector('lightning-datatable').getSelectedRows()[0].Id);
            console.log('i am here in delete ' + empId);
            
            
            deleteRecord(empId)
                .then(() => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Success',
                            message: 'Record deleted',
                            variant: 'success'
                        })
                    );
                })
               
                .catch(error => {
                    this.dispatchEvent(
                        new ShowToastEvent({
                            title: 'Error deleting record',
                            message: error.body.message,
                            variant: 'error'
                        })
                    );
                });
                this[NavigationMixin.Navigate]({
                    type: 'standard__webPage',
                    attributes: {
                        url:'https://gyaneasyskp-dev-ed.lightning.force.com/lightning/n/Employee2?0.source=alohaHeader'
                    },
                });
            
        }
    
}