import { LightningElement, track } from "lwc";

export default class HelloExpression extends LightningElement {
  @track fName = "";
  @track lName = "";
  @track uppercasedFullName='';

  handleChange(event) {
    const field = event.target.name;
    if (field === "firstName") {
      this.fName = event.target.value;
    } else if (field === "lastName") {
      this.lName = event.target.value;
    }
    
  }
//   get uppercasedFullName() {
//     return `${this.fName} ${this.lName}`.toUpperCase();
//   }

  show(event) {
    if (event.target.checked) {
      this.uppercasedFullName = `${this.fName} ${this.lName}`.toUpperCase();
    } else {
      this.uppercasedFullName = `${this.fName} ${this.lName}`;
    }
    return this.uppercasedFullName;
  }
}