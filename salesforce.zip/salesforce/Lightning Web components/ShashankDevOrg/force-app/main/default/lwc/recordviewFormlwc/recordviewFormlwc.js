import { LightningElement,api } from 'lwc';

export default class RecordviewFormlwc extends LightningElement {
    @api recordId;
}