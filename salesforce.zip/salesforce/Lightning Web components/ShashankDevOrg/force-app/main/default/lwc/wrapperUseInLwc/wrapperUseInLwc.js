import { LightningElement,wire } from 'lwc';
import getAllContacts from '@salesforce/apex/ContactController.getAllContacts';

export default class WrapperUseInLwc extends LightningElement {
    @wire(getAllContacts) contact;
}