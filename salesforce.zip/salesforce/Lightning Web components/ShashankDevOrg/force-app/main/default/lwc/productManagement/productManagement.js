import { LightningElement } from 'lwc';
import getProducts from '@salesforce/apex/ProductController.getProducts';
//importing getProducts() method to fetch existing records using Apex controller class
export default class ProductManagement extends LightningElement {
    columns = [
        { label: 'Enter Product Id', fieldName: 'Product_Id__c' },
        { label: 'Enter Product Name', fieldName: 'Name'},
        { label: 'Enter Product Type', fieldName: 'Type__c'},
        { label: 'Enter Product Price', fieldName: 'Price__c', type: 'currency' },
    ];
    productList; //it contains list of all products stored in the database
    reloadForm=true;
    constructor(){
        super();
        this.refreshList();
    }
    //using apex imperative method to bind data 
    refreshList(){
        getProducts()
        .then(result=>{
            this.productList=result;
        })
        .catch(error=>{
            alert('Error while fetching data');
        });
    }
    //to refresh our Page 
    handleSuccess(){
        this.refreshList();
    }
    
}