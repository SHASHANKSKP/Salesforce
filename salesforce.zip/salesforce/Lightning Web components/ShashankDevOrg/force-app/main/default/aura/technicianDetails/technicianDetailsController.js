({
	show : function(component, event, helper) {
        if(event.getParams().isSearch) {
            /*var req = component.get("c.showTechniciansBySearch");
            req.setParams({"searchString":event.getParams().searchStr});
            $A.enqueueAction(req);
            req.setCallback(this,function(res){
                if(res.getState()=="SUCCESS") {
                    component.set("v.clist", res.getReturnValue());
                }
            })*/
            helper.handleResponse(component,event,"c.showTechniciansBySearch",{"searchString":event.getParams().searchStr},"v.clist");
            console.log(JSON.parse(JSON.stringify(component.get("v.clist"))));
        } else {
            
            helper.handleResponse(component,event,"c:showTechniciansByState",{"searchString":event.getParams().searchStr},"v.clist");
        }
	}
})