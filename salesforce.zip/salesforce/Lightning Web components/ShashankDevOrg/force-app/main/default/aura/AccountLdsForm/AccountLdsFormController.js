({
	handleSubmit : function(component, event, helper) {
		event.preventDefault();   //stop the form from submitting
        const fields=event.getParam('fields');
        fields.Name='Hello'; //modify a field
        component.find('myRecordForm').submit(fields);
	}
})