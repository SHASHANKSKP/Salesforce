({
	handleResponse : function(component,event,method,params,target) {
		console.log("parent is called");
        var req = component.get(method);
            req.setParams(params);
            $A.enqueueAction(req);
            req.setCallback(this,function(res){
                if(res.getState()=="SUCCESS") {
                    component.set(target, res.getReturnValue());
                }
            })
	}
})